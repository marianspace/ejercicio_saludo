from setuptools import setup

setup(
    name = 'saludos',
    version = '0.1',
    author = 'LadyTopo',
    packages = ['saludos', 'saludos.adios', 'saludos.hola']

)
