def saludar():
    print('Hola funcion saludar')

class Hola():  
      def __init__(self):
        print('Digo Hola funcion __init')