def adios():
    print('Adios funcion adios')

class despedida():  
      def __init__(self):
        print('Digo adios funcion __init')